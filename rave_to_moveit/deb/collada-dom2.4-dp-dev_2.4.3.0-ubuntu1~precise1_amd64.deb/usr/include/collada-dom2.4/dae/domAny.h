// dummy file for backward compatibility with collada-dom versions <= 2.3
